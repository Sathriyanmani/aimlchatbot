"""An agent designed to hold a conversation in addition to using tools."""
