"""Chain that makes API calls and summarizes the responses to answer a question."""
